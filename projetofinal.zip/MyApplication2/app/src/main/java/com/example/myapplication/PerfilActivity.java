package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

public class PerfilActivity extends AppCompatActivity {

    private EditText nomeEditText;
    private Spinner timeCoracaoSpinner;
    private Spinner idadeSpinner;
    private Button saudacaoButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);

        nomeEditText = findViewById(R.id.nomeEditText);
        timeCoracaoSpinner = findViewById(R.id.timeCoracaoSpinner);
        idadeSpinner = findViewById(R.id.idadeSpinner);
        saudacaoButton = findViewById(R.id.saudacaoButton);

        ArrayAdapter<CharSequence> timeAdapter = ArrayAdapter.createFromResource(
                this,
                R.array.times_coracao_array, // array no arquivo strings.xml
                android.R.layout.simple_spinner_item
        );
        timeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        timeCoracaoSpinner.setAdapter(timeAdapter);

        // Configurar opções do Spinner para a idade
        ArrayAdapter<String> idadeAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                gerarOpcoesIdade(18, 50)
        );
        idadeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        idadeSpinner.setAdapter(idadeAdapter);
    }

    public void abrirSaudacao(View view) {
        String nome = nomeEditText.getText().toString();
        String timeCoracao = timeCoracaoSpinner.getSelectedItem().toString();
        String idade = idadeSpinner.getSelectedItem().toString();

        Intent intent = new Intent(this, SaudacaoActivity.class);
        intent.putExtra("nome", nome);
        intent.putExtra("idade", idade);
        intent.putExtra("timeCoracao", timeCoracao);
        startActivity(intent);
    }

    private List<String> gerarOpcoesIdade(int idadeInicial, int idadeFinal) {
        List<String> opcoesIdade = new ArrayList<>();
        for (int i = idadeInicial; i <= idadeFinal; i++) {
            opcoesIdade.add(String.valueOf(i));
        }
        return opcoesIdade;
    }
}