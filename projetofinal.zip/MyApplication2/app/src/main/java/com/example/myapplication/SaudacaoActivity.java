package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SaudacaoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saudacao);

        Intent intent = getIntent();
        String nome = intent.getStringExtra("nome");
        String idade = intent.getStringExtra("idade");
        String timeCoracao = intent.getStringExtra("timeCoracao");

        TextView textSaudacao = findViewById(R.id.textSaudacao);
        textSaudacao.setText("Olá, " + nome + "! " + idade + " anos");

        ImageView imageViewTime = findViewById(R.id.imageViewTime);
        switch (timeCoracao) {
            case "Santos":
                imageViewTime.setImageResource(R.drawable.santos);
                break;
            case "Vasco":
                imageViewTime.setImageResource(R.drawable.vasco);
                break;
            case "Avai":
                imageViewTime.setImageResource(R.drawable.avai);
                break;
            case "Internacional":
                imageViewTime.setImageResource(R.drawable.inter);
                break;
            case "Gremio":
                imageViewTime.setImageResource(R.drawable.gremio);
                break;

            default:
                break;
        }
    }
}